comPositions: computes the center of mass positions of each joint and beam and their generalized velocities

dc_motor: plotting of the DC motor dynamics for different R and L values

DFA: simulink DFA model
DFA_test: simulating DFA for different input strings

impacts: matlab ode events to check impacts occurring and terminating the integration

Mealy: simulink Mealy model
Mealy_test: simulating Mealy for different input strings

prerun: run before "simulink_system.slx"
postrun: run after "simulink_system.slx"
simulink_system.slx: cart-pendulum system with safety system. no impacts